package com.team3.itability.recruitment.dto;

public enum RecruitType {
    O, S
}
